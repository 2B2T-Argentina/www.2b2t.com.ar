<script type="text/javascript" src="script/jQuery_v1_4_2.js"></script>
<script type='text/javascript'>
function send(id) {
				$('#myStyle').load(id);
				}
			</script>
<script type="text/javascript">
function recp(id) {
	$('#myStyle').load(id);
}

$(document).ready(function () {
    var maxheight=14;
    var showText = "[Show replies]";
    var hideText = "[Hide replies]";

    $('.textContainer_Truncate').each(function () {
      var text = $(this);
      if (text.height() > maxheight){
          text.css({ 'overflow': 'hidden','height': maxheight + 'px' });

          var link = $('<a href="#textboard">' + showText + '</a>');
          var linkDiv = $("<div></div>");
          linkDiv.append(link);
          $(this).after(linkDiv);

          link.click(function (event) {
            event.preventDefault();
            if (text.height() > maxheight) {
                $(this).html(showText);
                text.css('height', maxheight + 'px');
            } else {
                $(this).html(hideText);
                text.css('height', 'auto');
            }
          });
      }       
    });
 });
</script>
<div style ="display: inline;">
<html>
<a href="#textboard" onClick="send('newThread.php')"> [New Thread]   </a>
<a href="#textboard" onClick="send('board.php')" > [Threads]</a>
<a >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="#textboard" onClick="send('archive.php')" >[Archive]</a>
</html>
</div>
		<html>
		<div class="post-content">
		<script type="text/javascript">
		function recp(id) {
			$('#myStyle').load("newReply.php?id=" + id);
		}
		</script>
		<p style='text-align: left;'><span style='font-size: 13px;color: rgb(178,148,187); font-weight:bold'>never4get   </span>
		<a><span style='font-size: 13px; color: rgb(96,164,32);  font-weight:bold'>Anonymous</a></span> 2014-05-01 11:45:46 No. 1013 Replies: 51<a href='#textboard' onClick='recp(1013)' > [Reply] </a> </p>		</div><a href="https://www.youtube.com/watch?v=VlSok_3Ym3w">https://www.youtube.com/watch?v=VlSok_3Ym3w</a><html>
	<div class="textContainer_Truncate">
		<p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-02 10:27:25 No. 1023</p>yes<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-02 16:44:12 No. 1033</p>never<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-03 07:48:25 No. 1044</p>bumpe<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-04 06:35:16 No. 1048</p>popbob
<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-04 19:18:01 No. 1050</p>always<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-06 08:08:29 No. 1055</p>ggg<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-07 08:21:59 No. 1059</p>666<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-08 18:59:49 No. 1079</p>SIC<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-09 05:33:22 No. 1080</p>420<br /><p style='text-align: left;'>
			<a href= 'mailto:autism@e-mail.ru'><span style='font-size: 10; text-decoration:underline; color: rgb(96,164,32); font-weight:bold;'>Popbob </a></span> 2014-05-09 07:29:38 No. 1081</p>When you read my name, you'll know who I am.
I am always online (BUT THE SERVER IS OFFLINE)
Haus, will you get the server online? Hause... hause... hause... hause...<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-10 07:24:23 No. 1086</p>triple<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-11 08:04:50 No. 1089</p>yes<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-12 08:43:33 No. 1090</p>sic erat scriptum<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-13 08:25:17 No. 1092</p>nigbob<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-14 18:00:01 No. 1095</p>4everOnTop<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-15 10:35:45 No. 1097</p>tinkerbell<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-16 06:43:51 No. 1106</p>u no wat time it is<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-17 18:40:17 No. 1110</p>TEAM EFFORT<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-18 11:56:09 No. 1111</p>cygnus inter anates
<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-18 16:01:06 No. 1113</p>hausemaster<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>hoarsemasterd </a></span> 2014-05-19 08:35:14 No. 1114</p>yes im hausemaster<br /><p style='text-align: left;'>
			<a href= 'mailto:heaven'><span style='font-size: 10; text-decoration:underline; color: rgb(96,164,32); font-weight:bold;'>heaven </a></span> 2014-05-19 19:38:46 No. 1115</p>Sage goes in all fields<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-20 08:18:13 No. 1116</p>tekken<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-21 06:48:53 No. 1121</p>unreal tournament<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-21 13:10:41 No. 1122</p>Mortal Cumbats<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-22 09:58:31 No. 1125</p>ssx<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-23 06:30:51 No. 1130</p>king kong<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-24 10:36:35 No. 1132</p>fuck
me<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-25 09:34:34 No. 1143</p>TWO B...

TWO T...<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-26 05:51:42 No. 1146</p>king fisher<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-27 07:59:24 No. 1147</p>race war now
a
c
e

w
a
r

n
o
w<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-28 06:16:03 No. 1149</p>vote today<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-28 10:14:09 No. 1150</p>Happened today on the drive home from class

&gt;Be driving in my 1999 Honda Accord shitbox (autotragic)
&gt;Dudebro in 90s V6 Rustang pulls up to me at stop light and revs like a maniac
&gt;mfw he has less horsepower than me
&gt;Beat him in drag race
&gt;hfw his &quot;mussle kar&quot; got beat by a japanese 4 banger econobox

Any stories of beating some cocky yet uninformed douche in a race with your &quot;inferior&quot; car?<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-28 10:41:20 No. 1151</p>    &gt; found out my ex was banging a new guy.
    &gt; guy is married
    &gt; decide to fuck her over
    &gt; say I'm coming to visit in a few days
    &gt; immediately drive 8 hours
    &gt; surprisebitch.jpg
    &gt; say I miss her, want to patch things up
    &gt; waiting for right moment
    &gt; takes days
    &gt; get her drunk as fuck
    &gt; rail her all night
    &gt; take video of fucking
    &gt; wait for her to pass out
    &gt; steal phone and copy contacts/text history
    &gt; lay in wait
    &gt; she breaks it off with other penis
    &gt; 2 more days, get her drunk again
    &gt; she loves the cock now
    &gt;in the morning tell her it's over
    &gt; she blacked out and is confused
    &gt; use leverage to bang the shit out of her
    &gt; allbetternow.me
    &gt; say I'm going to store, drive 8 hours home
    &gt; 100 missed calls
    &gt; get home, find details on other cock
    &gt; call his wife and tell her guy is fucking ex
    &gt;send gif of me fucking her to all contacts
    &gt; send her msg that says fuck you
    &gt; missed work fo<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-28 10:43:28 No. 1152</p>Hey Faggots,
My name is John, and I hate every single one of you. All of you are fat, retarded, no-lifes who spend every second of their day looking at stupid ass pictures. You are everything bad in the world. Honestly, have any of you ever gotten any pussy? I mean, I guess it&acirc;��s fun making fun of people because of your own insecurities, but you all take to a whole new level. This is even worse than jerking off to pictures on facebook.
Don&acirc;��t be a stranger. Just hit me with your best shot. I&acirc;��m pretty much perfect. I was captain of the football team, and starter on my basketball team. What sports do you play, other than &acirc;��jack off to naked drawn Japanese people&acirc;��? I also get straight A&acirc;��s, and have a banging hot girlfriend (She just blew me; Shit was SO cash). You are all faggots who should just kill yourselves. Thanks for listening.<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-28 10:45:11 No. 1153</p>Overview

2014 Isla Vista Killings were a killing spree that took place near the campus of University of California, Santa Barbara on the night of May 23rd, 2014, which claimed the lives of six students and wounded 13 others. The perpetrator was identified as Elliot Rodger, a 22-year-old student at Santa Barbara City College, who was later found dead in his vehicle.<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-28 10:45:22 No. 1154</p>On the night of May 23rd, 2014, a 22-year-old University of California student named Elliot Rodger went on a mass killing spree near the Santa Barbara campus in Isla Vista, California, killing seven people, including himself, and wounding 13 others. The spree began in the evening with the fatal stabbings of his roommates in his apartment, Cheng Yuan &acirc;��James&acirc;�� Hong, George Chen and Weihan &acirc;��David&acirc;�� Wang, and continued with a series of drive-by shootings and vehicular assaults near the campus, which resulted in the deaths of three students Katherine Cooper, Veronika Weiss and Christopher Michael-Martinez. After engaging several police officers on the road and crashing into a parked vehicle, Rodger was found dead in his vehicle with a self-inflicted bullet wound to his head.<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-29 09:52:06 No. 1155</p>nimble<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-30 09:41:01 No. 1158</p>nymbus 2000
<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-05-31 15:01:57 No. 1161</p>vroom<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-01 05:51:32 No. 1163</p>9999<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-02 05:52:27 No. 1164</p>thats not my name<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-03 05:59:46 No. 1168</p>the ting tings<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-04 02:19:46 No. 1174</p>good times<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-04 14:34:29 No. 1179</p>Vladimir Putin<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-05 07:07:42 No. 1180</p>trip<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-06 05:29:54 No. 1181</p>bloods and crips<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-06 08:57:32 No. 1182</p>and the kkk<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-06 18:46:31 No. 1183</p>cringe kong
<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-07 10:28:11 No. 1184</p>Let's count to 5. ILL START! 1<br /><p style='text-align: left;'>
			<a><span style='font-size: 10;  color: rgb(96,164,32); font-weight:bold;'>Anonymous </a></span> 2014-06-07 12:23:38 No. 1185</p>le 2<br />
	</div>
	</html>
	<hr>