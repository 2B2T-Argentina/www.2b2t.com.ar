<iframe style="width:728px;height:90px;max-width:100%;border:none;display:block;margin:auto" src="https://namemc.com/server/2b2t.com.ar/embed" width="728" height="90"></iframe>
